As suggested in "Part 2 - Building the Command Line Application" I tried to run

	pip install -q -U "tensorflow-gpu==2.0.0b1"
    
and 

	pip install -q -U tensorflow_hub
    
in the command line of the workspace.
When I do this, I get the following error message:

	ERROR: Could not install packages due to an EnvironmentError: [Errno 30] Read-only file system: '/opt/conda/envs/TF2.0/lib/python3.7/site-packages/tensorflow_estimator/__init__.py'
    
Can I do anything about this?
Can I ignore this?

However, when trying to run my script

	python predict.py test_images/wild_pansy.jpg best_model.h5 
    
I get

	ValueError: Unknown layer: KerasLayer.

The error occurs in the line where I load my saved model:

	tf.keras.models.load_model(path)

and also when I do 

	tf.keras.models.load_model(path,custom_objects={'KerasLayer':hub.KerasLayer})

as suggested in https://stackoverflow.com/questions/61814614/unknown-layer-keraslayer-when-i-try-to-load-model

However, on my machine, everything works as supposed.
What is going wrong in the workspace?
What do I need to change to make it work?