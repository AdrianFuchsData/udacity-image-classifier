import argparse
import logging
import predict_utility
import sys

doc = """Image classifier. Predict the name of a flower.

Returns for a given input picture and a TensorFlow Model the indices (or names
is if -c is set and probabilities of the top flowers that the model guesses.

The script prints the pair (or a list of pairs if -t is set) consising of the
flower index or name in the first component and its probability in the second
component to stdout.
"""

parser = argparse.ArgumentParser(
    description=doc,
)

parser.add_argument('image', metavar='image_path',
                    type=str,
                    help='Path to image file')

parser.add_argument('saved_model', metavar='model_path',
                    type=str,
                    help='Path to saved TensorFlow model (in hdf5 format)')

parser.add_argument('-t', '--top_k', action='store',
                    dest='top_k_classes',
                    default=0,
                    type=int,
                    help='Number of top classes displayed')

parser.add_argument('-c', '--category_names', action='store',
                    dest='category_names',
                    default=None,
                    type=str,
                    help='Path to a JSON file mapping labels to flower names')

parser.add_argument('-v', '--version', action='version',
                    version='%(prog)s 1.0')

args = parser.parse_args()

model = predict_utility.load_model(args.saved_model)
prediction = predict_utility.predict(
    image_path=args.image,
    model=model,
    top_k=max(1,args.top_k_classes)
)

if args.category_names is not None:
    classes = list(zip(
        predict_utility.json_map(args.category_names,prediction[1]),
        prediction[0],
    ))
else:
    classes = list(zip(prediction[1],prediction[0]))

if args.top_k_classes:
    sys.stdout.write(str(classes))
else:
    sys.stdout.write(str(classes[0]))
sys.exit(0)