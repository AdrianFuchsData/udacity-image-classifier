import tensorflow as tf
import tensorflow_hub as hub
import predict_utility

def load_model(path: str):
    "Load a saved model"
    try:
        return(tf.keras.models.load_model(path,custom_objects={'KerasLayer':hub.KerasLayer}))
    except KeyError:
        try:
            return(tf.keras.models.load_model(path))
        except Exception:
            return(tf.keras.experimental.load_from_saved_model(path, custom_objects={'KerasLayer':hub.KerasLayer}))