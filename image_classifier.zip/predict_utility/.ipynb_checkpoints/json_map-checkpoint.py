import json
import predict_utility

def json_map(file_name: str, items: list):
    """
    Trys to map list items according to a dictionary
    loaded as a JSON file.
    
    All items that do not have a matching key in the
    dictionary remain unchanged.
    
    If the input file does not exist, is not loadable
    or corrupted, the whole item list is returned
    as is was given.
    """
    try:
        with open(file_name,"r") as file:
            map_dict = json.load(file)
    except FileNotFoundError:
        return(items)
    if not isinstance(map_dict,dict):
        return(items)
    return([map_dict.get(ii,map_dict.get(str(ii),ii)) for ii in items])