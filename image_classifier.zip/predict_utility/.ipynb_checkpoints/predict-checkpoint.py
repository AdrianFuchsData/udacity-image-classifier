from PIL import Image
import numpy as np
import tensorflow as tf
import predict_utility

def predict(image_path: str,
            model: tf.keras.Sequential,
            top_k: int):
    """Return a pair of length top_k lists:
    First list contains probabilities that the input image
    belongs to the class of the given entry of the second list
    The second list consists of the class labels (int values).
    """
    im = Image.open(image_path)
    image = np.asarray(im)
        
    image = predict_utility.process_image(image)
    image = np.array([image])
    prediction = model.predict(image)
    labelled_prediction = [(prediction[0][ii],ii+1) for ii in range(len(prediction[0]))]
    labelled_prediction.sort(reverse=True)
    return ([labelled_prediction[ii][0] for ii in range(top_k)],
            [labelled_prediction[ii][1] for ii in range(top_k)],
           )