import numpy as np
import tensorflow as tf
import predict_utility

def process_image(image: np.ndarray):
    """
    Resize an input image to a size of 224 x 224
    and scales the pixel values to the unit interval.
    """
    picture_in_tf = tf.convert_to_tensor(image/255)
    resized_image = tf.image.resize(picture_in_tf,(224,224))
    return(resized_image.numpy())